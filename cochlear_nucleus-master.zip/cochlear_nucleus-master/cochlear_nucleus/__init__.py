# -*- coding: utf-8 -*-

"""NEURON and Brian models of Globular Bushy Cells.

"""
from __future__ import division, print_function, absolute_import
from __future__ import unicode_literals

__author__ = "Marek Rudnicki"
__copyright__ = "Copyright 2015, Marek Rudnicki"
__license__ = "GPLv3+"
__version__ = "1.4"
